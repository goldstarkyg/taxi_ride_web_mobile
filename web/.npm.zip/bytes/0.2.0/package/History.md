
0.2.0 / 2012-10-28 
==================

  * bytes(200).should.eql('200b')

0.1.0 / 2012-07-04 
==================

  * add bytes to string conversion [yields]
